package com.umenu.umenu;

import android.content.Intent;
import android.graphics.Typeface;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.ViewPropertyAnimatorCompatSet;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import android.widget.Toast;



import java.util.Scanner;


public class MainActivity extends AppCompatActivity {
    public static int timeout = 4000;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button menu;

        ImageButton setting;
        ImageButton share;

        menu =  (Button)findViewById(R.id.btnMenu);

        setting = (ImageButton)findViewById(R.id.settings);
        share = (ImageButton) findViewById(R.id.share);
        menu.setTransformationMethod(null);


        share.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Toast.makeText(getBaseContext(), "Share Button Pushed", Toast.LENGTH_LONG) .show();
            }

        });



        setting.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){

                Intent setting_page = new Intent(MainActivity.this, Setting_activity.class);
                startActivity(setting_page);




            }
        });



        menu.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v){


                //Toast.makeText(getBaseContext(), "Menu button pushed", Toast.LENGTH_LONG) .show();

                Intent setting_page = new Intent(MainActivity.this, RestaurantListActivity.class);
                startActivity(setting_page);




            }

        });

    }

    public void buttonclick(View v)
    {

        Toast.makeText(getBaseContext(), "you clicked the button", Toast.LENGTH_LONG) .show();


    }

    public void searchClicked(View v){

    }
}
